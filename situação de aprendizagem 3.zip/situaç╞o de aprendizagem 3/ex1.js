function clicar(){
    alert('Você clicou no botão!');
}
