function mudar(){
    let num = Number(window.prompt("Digite um número:"));
    let res = num - 1;
    let res2 = num + 1;
    alert(`O antecessor de ${num} é ${res} e o sucessor é ${res2}`);
}