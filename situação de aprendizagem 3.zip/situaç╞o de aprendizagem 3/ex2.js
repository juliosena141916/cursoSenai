function dados(){
    var nome = window.prompt("Qual é o seu nome?"); 
    var idade = Number(window.prompt("Qual é a sua idade?"));
    alert(`Olá, ${nome}! Você tem ${idade} anos.`);
}