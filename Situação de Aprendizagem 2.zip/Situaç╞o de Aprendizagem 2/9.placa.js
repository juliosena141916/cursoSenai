let placas = ["ABC1234", "DEF5678", "GHI9101"];
let placa = prompt("Digite a placa do veículo:");

if (placa === placas[0] || placa === placas[1] || placa === placas[2]) {
    alert("Acesso permitido");
} else {
    alert("Acesso negado");
}


