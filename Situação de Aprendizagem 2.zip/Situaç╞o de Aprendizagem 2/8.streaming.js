function exibirStreamings() {
    return prompt(
        "Menu:\n" +
        "Prime video - R$166.80/ano\n" +
        "Disney plus - R$368.90/ano\n" +
        "HBO - R$225.90/ano\n" +
        "Escolha uma opção:"
    );
}
exibirStreamings();