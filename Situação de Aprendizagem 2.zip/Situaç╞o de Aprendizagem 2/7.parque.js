let inteira = 36;
let meia = 18;

function exibirMenu() {
    return prompt(
        "Menu:\n" +
        "1 - Entrada inteira: R$36.00\n" +
        "2 - Meia entrada: R$18.00\n" +
        "3 - Sair\n" +
        "Escolha uma opção:"
    );
}
exibirMenu();